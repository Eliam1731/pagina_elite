import React from "react";
import { Card, CardBody } from "@heroui/react";
import { Icon } from "@iconify/react";
import { motion } from "framer-motion";

export const ProcessSection: React.FC = () => {
  const steps = [
    { icon: "lucide:pencil-ruler", title: "Diseño", desc: "Conceptos personalizados según tu identidad y colores.", tone: "ring-primary/30 text-primary" },
    { icon: "lucide:settings", title: "Producción", desc: "Materiales premium y confección precisa.", tone: "ring-white/20 text-white/90" },
    { icon: "lucide:printer", title: "Sublimación", desc: "Impresión HD duradera con acabado profesional.", tone: "ring-primary/30 text-primary" },
    { icon: "lucide:package", title: "Entrega", desc: "Control de calidad y envío a tiempo.", tone: "ring-white/20 text-white/90" },
  ];

  return (
    <section id="process" className="py-20 md:py-28 bg-content2">
      <div className="container mx-auto px-4">
        <div className="section-fade-in">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-white">
              Nuestro <span className="text-primary">Proceso</span>
            </h2>
            <p className="text-foreground-500 max-w-2xl mx-auto mt-3">
              Cómo fabricamos uniformes de alta calidad, paso a paso.
            </p>
          </div>

          <div className="relative">
            <div className="hidden md:block absolute left-1/2 -translate-x-1/2 top-9 h-px w-full max-w-5xl bg-white/10" />
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {steps.map((s, i) => (
                <motion.div key={i} initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: .35, delay: .08 * i }} className="relative">
                  <Card className="bg-[#0F1322] border border-white/5 shadow-none">
                    <CardBody className="p-6">
                      <div className={`absolute -top-6 left-1/2 -translate-x-1/2 w-12 h-12 rounded-full bg-black/50 backdrop-blur-sm flex items-center justify-center ring-2 ${s.tone}`}>
                        <Icon icon={s.icon} className="text-xl" />
                      </div>
                      <div className="mt-6 text-center">
                        <h3 className="text-white font-semibold mb-2">{s.title}</h3>
                        <p className="text-foreground-500 text-sm">{s.desc}</p>
                      </div>
                    </CardBody>
                  </Card>
                  <div className="hidden md:flex absolute -top-3 left-1/2 -translate-x-1/2 text-[11px] font-bold bg-white/10 text-white/80 rounded-full w-6 h-6 items-center justify-center">
                    {i + 1}
                  </div>
                </motion.div>
              ))}
            </div>
          </div>

          <div className="mt-14 rounded-xl border border-white/5 bg-white/5 p-6 md:p-8">
            <div className="flex flex-col md:flex-row items-center gap-5">
              <div className="w-12 h-12 rounded-full bg-primary/15 flex items-center justify-center flex-shrink-0">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-primary" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <path d="M12 8v4l3 3" />
                  <circle cx="12" cy="12" r="10" />
                </svg>
              </div>
              <p className="text-foreground-500">
                Tiempos optimizados: pedidos estándar en <span className="text-white">2–3 semanas</span>. Opciones express disponibles.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
