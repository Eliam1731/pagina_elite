import React from "react";
import { Button, Link } from "@heroui/react";
import { Icon } from "@iconify/react";
import { motion } from "framer-motion";

export const HeroSection: React.FC = () => {
  return (
    <section className="relative pt-32 pb-20 md:pt-40 md:pb-28 overflow-hidden hero-gradient">
      <div className="container mx-auto px-4 relative z-10">
        <div className="flex flex-col lg:flex-row items-center gap-12 lg:gap-8">
          <div className="w-full lg:w-1/2 text-center lg:text-left">
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }}>
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight mb-6 text-white">
                Uniformes deportivos sublimados de <span className="text-primary">alto rendimiento</span>
              </h1>
              <p className="text-foreground-500 text-lg md:text-xl mb-8 max-w-xl mx-auto lg:mx-0">
                Diseños personalizados que elevan la identidad de tu equipo. Calidad premium, durabilidad superior y estilo único.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
                <Button as={Link} href="#contact" color="primary" size="lg" className="font-medium text-base" startContent={<Icon icon="lucide:clipboard-check" />}>
                  Cotiza tu uniforme ahora
                </Button>
                <Button as={Link} href="#portfolio" variant="bordered" color="primary" size="lg" className="font-medium text-base text-white" startContent={<Icon icon="lucide:image" />}>
                  Ver portafolio
                </Button>
              </div>
              <div className="mt-8 flex items-center gap-6 justify-center lg:justify-start">
                <div className="flex -space-x-3">
                  {[1,2,3,4].map((id) => (
                    <div key={id} className="w-10 h-10 rounded-full border-2 border-white overflow-hidden">
                      <img src={`https://img.heroui.chat/image/avatar?w=100&h=100&u=${id}`} alt="Cliente satisfecho" className="w-full h-full object-cover" />
                    </div>
                  ))}
                </div>
                <div className="text-sm text-foreground-500">
                  <strong className="text-white">+500</strong> equipos satisfechos
                </div>
              </div>
            </motion.div>
          </div>

          <div className="w-full lg:w-1/2 jersey-3d-container">
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.8, delay: 0.3 }} className="relative">
              <div className="jersey-3d relative w-full h-[400px] md:h-[500px] flex items-center justify-center">
                <div className="absolute inset-0 bg-gradient-to-br from-primary/10 to-transparent rounded-full opacity-70" />
                <img src="https://img.heroui.chat/image/sports?w=600&h=600&u=jersey1" alt="Jersey 3D" className="max-w-full max-h-full object-contain" />
                <div className="absolute -bottom-4 left-1/2 transform -translate-x-1/2 w-3/4 h-8 bg-black/40 filter blur-xl rounded-full" />
              </div>
            </motion.div>
          </div>
        </div>
      </div>
      <div className="absolute bottom-0 left-0 right-0 h-16 bg-gradient-to-t from-background to-transparent" />
    </section>
  );
};
