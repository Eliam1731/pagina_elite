import React from "react";
import { Navbar as HeroNavbar, NavbarBrand, NavbarContent, NavbarItem, NavbarMenuToggle, NavbarMenu, NavbarMenuItem, Link, Button } from "@heroui/react";
import { Icon } from "@iconify/react";

export const Navbar: React.FC = () => {
  const [isMenuOpen, setIsMenuOpen] = React.useState(false);
  const [isScrolled, setIsScrolled] = React.useState(false);

  React.useEffect(() => {
    const onScroll = () => setIsScrolled(window.scrollY > 20);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const menuItems = [
    { name: "Inicio", href: "#" },
    { name: "Portafolio", href: "#portfolio" },
    { name: "Proceso", href: "#process" },
    { name: "Personalización", href: "#customization" },
    { name: "Testimonios", href: "#testimonials" },
    { name: "FAQ", href: "#faq" },
    { name: "Contacto", href: "#contact" },
  ];

  return (
    <HeroNavbar
      isMenuOpen={isMenuOpen}
      onMenuOpenChange={setIsMenuOpen}
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${isScrolled ? "bg-black/90 backdrop-blur-md shadow-sm" : "bg-transparent"}`}
      maxWidth="xl"
    >
      <NavbarContent>
        <NavbarMenuToggle aria-label={isMenuOpen ? "Close menu" : "Open menu"} className="sm:hidden" />
        <NavbarBrand>
          <div className="flex items-center gap-2">
            <div className="bg-primary p-1 rounded-md">
              <Icon icon="lucide:shirt" className="text-white text-xl" />
            </div>
            <p className="font-bold text-inherit text-xl text-white">
              Elite<span className="text-primary">Designs</span>
            </p>
          </div>
        </NavbarBrand>
      </NavbarContent>

      <NavbarContent className="hidden sm:flex gap-6" justify="center">
        {menuItems.slice(0, 6).map((item, i) => (
          <NavbarItem key={i}>
            <Link href={item.href} color="foreground" className="font-medium text-sm text-white/80 hover:text-primary transition-colors">
              {item.name}
            </Link>
          </NavbarItem>
        ))}
      </NavbarContent>

      <NavbarContent justify="end">
        <NavbarItem className="hidden sm:flex">
          <Button as={Link} color="primary" href="#contact" variant="solid" className="font-medium">
            Cotiza ahora
          </Button>
        </NavbarItem>
      </NavbarContent>

      <NavbarMenu className="pt-6 bg-background">
        {menuItems.map((item, i) => (
          <NavbarMenuItem key={i}>
            <Link href={item.href} color="foreground" className="w-full font-medium text-lg py-2 text-white" size="lg">
              {item.name}
            </Link>
          </NavbarMenuItem>
        ))}
        <NavbarMenuItem className="mt-6">
          <Button as={Link} color="primary" href="#contact" variant="solid" className="w-full font-medium">
            Cotiza ahora
          </Button>
        </NavbarMenuItem>
      </NavbarMenu>
    </HeroNavbar>
  );
};
