import { heroui } from "@heroui/react";

/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
    "./node_modules/@heroui/theme/dist/**/*.{js,ts,jsx,tsx}",
  ],
  theme: { extend: {} },
  darkMode: "class",
  plugins: [
    heroui({
      layout: {
        dividerWeight: "1px",
        disabledOpacity: 0.45,
        fontSize: { tiny: "0.75rem", small: "0.875rem", medium: "0.9375rem", large: "1.125rem" },
        lineHeight: { tiny: "1rem", small: "1.25rem", medium: "1.5rem", large: "1.75rem" },
        radius: { small: "6px", medium: "8px", large: "12px" },
        borderWidth: { small: "1px", medium: "1px", large: "2px" },
      },
      themes: {
        light: {
          colors: {
            background: { DEFAULT: "#0B0B0F" },
            foreground: { DEFAULT: "#FFFFFF", 500: "#9CA3AF", 600: "#8B949E" },
            content1: { DEFAULT: "#111216", foreground: "#FFFFFF" },
            content2: { DEFAULT: "#141826", foreground: "#FFFFFF" },
            content3: { DEFAULT: "#1A2032", foreground: "#FFFFFF" },
            content4: { DEFAULT: "#20283D", foreground: "#FFFFFF" },
            divider: { DEFAULT: "rgba(255,255,255,0.08)" },
            overlay: { DEFAULT: "#000000" },
            default: { DEFAULT: "#2A3248", foreground: "#fff" },
            primary: {
              50: "#e6eeff",100: "#ccdcff",200: "#99b9ff",300: "#6696ff",
              400: "#3373ff",500: "#0047CC",600: "#0039a3",700: "#002b7a",
              800: "#001c52",900: "#000e29",DEFAULT: "#0047CC",foreground: "#fff",
            },
            success: { DEFAULT: "#17c964", foreground: "#000" },
            warning: { DEFAULT: "#f5a524", foreground: "#000" },
            danger:  { DEFAULT: "#f31260", foreground: "#fff" },
          },
        },
      },
    }),
  ],
};
